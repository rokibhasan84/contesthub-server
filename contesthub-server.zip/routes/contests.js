const express = require('express');
const router = express.Router();
const Contest = require('../models/Contest');
const verifyJWT = require('../middleware/verifyJWT');
const verifyCreator = require('../middleware/verifyCreator');

// create contest (creator/admin) — for now allow any authenticated
router.post("/", verifyJWT, verifyCreator, async (req, res) => {
  try {
    console.log("===== ADD CONTEST API HIT =====");
    console.log("Headers:", req.headers);
    console.log("Decoded user:", req.decoded);
    console.log("Body:", req.body);

    const contest = req.body;

    if (!contest.name || !contest.image || !contest.type) {
      return res.status(400).send({ message: "Missing required fields" });
    }

    contest.status = "pending";
    contest.participantsCount = 0;
    contest.deadline = new Date(contest.deadline);

    const result = await Contest.create(contest);
    res.send(result);

  } catch (error) {
    console.error("🔥 ADD CONTEST ERROR 🔥", error);
    res.status(500).send({ message: error.message });
  }
});

// get all contests
router.get("/", async (req, res) => {
  const {
    status,
    search,
    type,
    sort,
    page = 1,
    limit = 6
  } = req.query;

  const query = {};
  if (status) query.status = status;
  if (type) query.type = type;

  if (search) {
    query.name = { $regex: search, $options: "i" };
  }

  // filter by type

  if (type) {
    query.type = type;
  }
  // only approved contests
    query.status = "approved";

  let contestsQuery = Contest.find(query);

  if (sort === "price_asc") contestsQuery.sort({ price: 1 });
  if (sort === "price_desc") contestsQuery.sort({ price: -1 });

  const total = await Contest.countDocuments(query);

  const contests = await contestsQuery
    .skip((page - 1) * limit)
    .limit(Number(limit));

  res.send({
    contests,
    total,
    totalPages: Math.ceil(total / limit),
    currentPage: Number(page)
  });
});



router.get("/popular", async (req, res) => {
  const contests = await Contest.find({ status: "approved" })
    .sort({ participantsCount: -1 })
    .limit(6);

  res.send(contests);
});


// get by id
router.get('/:id', async (req, res) => {
  const contest = await Contest.findById(req.params.id);
  if (!contest) return res.status(404).send({ message: 'Not found' });
  res.send({ contest });
});

// update contest status
router.patch("/:id/approve", verifyJWT, async (req, res) => {
  const result = await Contest.findByIdAndUpdate(
    req.params.id,
    { status: "approved" },
    { new: true }
  );
  res.send(result);
});

router.delete("/:id", verifyJWT, async (req, res) => {
  await Contest.findByIdAndDelete(req.params.id);
  res.send({ success: true });
});



module.exports = router;